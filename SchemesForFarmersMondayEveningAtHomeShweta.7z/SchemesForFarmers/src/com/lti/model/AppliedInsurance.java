package com.lti.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import oracle.sql.DATE;

@Entity
@Scope(value = "prototype")
@Component
@Table(name = "tblInsuranceApplied1")
@SequenceGenerator(name = "insurance_applied", sequenceName = "seq_insurance_applied")
public class AppliedInsurance implements Serializable {

	@Id
	@Column(name = "policy_no")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "insurance_applied")
	private int policyNo;

	@Column(name = "company_name")
	private String companyName;

	@Column(name = "c_year")
	private int year;
	
	@Column(name = "applied_date")
	private String appliedDate;

	
	@Column(name = "status")
	private String status;

	@Column(name = "crop_name")
	private String cropName;

	@Column(name = "total_sum_insured")
	private long totalSumInsured;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	public AppliedInsurance() {

	}

	public AppliedInsurance(int policyNo, String companyName, int year, String status, long totalSumInsured, String cropName) {
		super();
		this.policyNo = policyNo;
		this.cropName = cropName;
		this.companyName = companyName;
		this.year = year;
		this.status = status;
		this.totalSumInsured = totalSumInsured;
	}

	
	
	public String getCropName() {
		return cropName;
	}

	public void setCropName(String cropName) {
		this.cropName = cropName;
	}

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getTotalSumInsured() {
		return totalSumInsured;
	}

	public void setTotalSumInsured(long totalSumInsured) {
		this.totalSumInsured = totalSumInsured;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(String appliedDate) {
		this.appliedDate = appliedDate;
	}


}
