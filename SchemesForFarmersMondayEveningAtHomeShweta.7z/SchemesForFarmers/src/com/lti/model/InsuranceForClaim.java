package com.lti.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Scope(value = "prototype")
@Component
@Table(name = "tblInsuranceClaimes1")
@SequenceGenerator(name = "insurance_claimed", sequenceName = "seq_insurance_claimed")
public class InsuranceForClaim implements Serializable {

	
	@Id
	@Column(name = "insurance_claim_id")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "insurance_claimed")
	private int insuranceClaimId;

	@Column(name = "date_of_loss")
	private String dateOfLoss;

	@Column(name = "cause_of_loss")
	private String causeOfLoss;

	@Column(name = "status")
	private String claimStatus;
	
	@OneToOne
	@JoinColumn(name = "policy_no")
	private AppliedInsurance policyNo;


	public InsuranceForClaim() {

	}

	public InsuranceForClaim(String dateOfLoss, String causeOfLoss, String claimStatus) {
		super();
		this.dateOfLoss = dateOfLoss;
		this.causeOfLoss = causeOfLoss;
		this.claimStatus = claimStatus;
	}

	
	
	
	public int getInsuranceClaimId() {
		return insuranceClaimId;
	}

	public void setInsuranceClaimId(int insuranceClaimId) {
		this.insuranceClaimId = insuranceClaimId;
	}

	public AppliedInsurance getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(AppliedInsurance policyNo) {
		this.policyNo = policyNo;
	}

	public String getDateOfLoss() {
		return dateOfLoss;
	}

	public void setDateOfLoss(String dateOfLoss) {
		this.dateOfLoss = dateOfLoss;
	}

	public String getCauseOfLoss() {
		return causeOfLoss;
	}

	public void setCauseOfLoss(String causeOfLoss) {
		this.causeOfLoss = causeOfLoss;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	@Override
	public String toString() {
		return "InsuranceForClaim [policyNo=" + policyNo + ", dateOfLoss=" + dateOfLoss + ", causeOfLoss=" + causeOfLoss
				+ ", claimStatus=" + claimStatus + "]";
	}

}
