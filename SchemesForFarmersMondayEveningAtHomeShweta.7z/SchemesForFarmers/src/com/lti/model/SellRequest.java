package com.lti.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Scope(value = "prototype")
@Component
@Table(name = "tblSellRequests1")
@SequenceGenerator(name = "sell_seq", sequenceName = "sellRequest_seq1")
public class SellRequest implements Serializable{

	@Id
	 @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sell_seq")
	@Column(name="request_id")
	private int requestId;
	
	@Column(name="fertilizer_type")
	private String fertilizerType;
	
	private int quantity;
	
	@Column(name="ph_certificate")
	private String phCertificate;
	
	@Column(name="base_price")
	private float basePrice;
	
	private String status;
	
	@Column(name="request_date")
	private String requestDate;
	
	@Column(name="current_bid")
	private float currentBid;
	
	

	@OneToOne
	@JoinColumn(name = "crop_id")
	private Crop crop;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	public SellRequest() {
		super();
	}

	public SellRequest(int requestId, String fertilizerType, int quantity, String phCertificate, float basePrice,
			String status, String requestDate, float currentBid) {
		super();
		this.requestId = requestId;
		this.fertilizerType = fertilizerType;
		this.quantity = quantity;
		this.phCertificate = phCertificate;
		this.basePrice = basePrice;
		this.status = status;
		this.requestDate = requestDate;
		this.currentBid = currentBid;
	}

	public int getrequestId() {
		return requestId;
	}

	public void setrequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getfertilizerType() {
		return fertilizerType;
	}

	public void setfertilizerType(String fertilizerType) {
		this.fertilizerType = fertilizerType;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getphCertificate() {
		return phCertificate;
	}

	public void setphCertificate(String phCertificate) {
		this.phCertificate = phCertificate;
	}

	public float getbasePrice() {
		return basePrice;
	}

	public void setbasePrice(float basePrice) {
		this.basePrice = basePrice;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getrequestDate() {
		return requestDate;
	}

	public void setrequestDate(String requestDate) {
		this.requestDate = requestDate;
	}

	public float getcurrentBid() {
		return currentBid;
	}

	public void setcurrentBid(float currentBid) {
		this.currentBid = currentBid;
	}

	public Crop getCrop() {
		return crop;
	}

	public void setCrop(Crop crop) {
		this.crop = crop;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "SellRequest [requestId=" + requestId + ", fertilizerType=" + fertilizerType + ", quantity="
				+ quantity + ", phCertificate=" + phCertificate + ", basePrice=" + basePrice + ", status=" + status
				+ ", requestDate=" + requestDate + ", currentBid=" + currentBid + ", crop=" + crop + ", user="
				+ user + "]";
	}

}
