package com.lti.dao;

import java.awt.print.Book;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.lti.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	public int createUser(User user) {
		entityManager.persist(user);
		return 1;
	}

	public User readUserLogin(String username, String password) {
		
		User user;
		String jpql = "Select u from User u where u.email=:username and u.password=:password";
		TypedQuery<User> tquery = entityManager.createQuery(jpql, User.class);
		tquery.setParameter("username", username);
		tquery.setParameter("password", password);
		if (tquery.getResultList().size() != 0) {
			user = tquery.getSingleResult();
			return user;
		} else 
			return null;

	}

}
