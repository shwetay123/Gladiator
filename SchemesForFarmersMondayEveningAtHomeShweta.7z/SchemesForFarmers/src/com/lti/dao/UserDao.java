package com.lti.dao;

import com.lti.model.User;

public interface UserDao {

	public int createUser(User user);
	
	public User readUserLogin(String username,String password);
	
	
}
