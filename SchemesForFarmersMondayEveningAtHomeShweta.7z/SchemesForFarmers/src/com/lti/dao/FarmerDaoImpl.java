package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.AppliedInsurance;
import com.lti.model.BidRequest;
import com.lti.model.Crop;
import com.lti.model.InsuranceForClaim;
import com.lti.model.Land;
import com.lti.model.SellRequest;
import com.lti.model.User;

@Repository
public class FarmerDaoImpl implements FarmerDao {

	@PersistenceContext
	private EntityManager entityManager;

	public List<Crop> readAllCrops() {

		String jpql4 = "from Crop";

		TypedQuery<Crop> tquery = entityManager.createQuery(jpql4, Crop.class);

		List<Crop> crops = tquery.getResultList();

		if (crops.size() != 0) {
			return crops;
		} else {
			return null;
		}
	}

	public Crop readCropById(int cropId) {
		Crop crop = entityManager.find(Crop.class, cropId);
		return crop;
	}

	public int insertSellRequest(SellRequest sellRequest) {
		System.out.println(sellRequest);
		entityManager.persist(sellRequest);
		System.out.println("Sell Request");
		return 1;
	}

	public User readUserById(int userId) {
		User user = entityManager.find(User.class, userId);
		return user;
	}

	public int insertLandDetails(Land land) {
		entityManager.merge(land);
		return 1;
	}

	public List<Land> readAllLands() {

		String jpql4 = "from Land";

		TypedQuery<Land> tquery = entityManager.createQuery(jpql4, Land.class);

		List<Land> lands = tquery.getResultList();

		if (lands.size() != 0) {
			return lands;
		} else {
			return null;
		}
	}

	public SellRequest readSellRequestById(int sellRequestId) {
		SellRequest sellRequest2 = entityManager.find(SellRequest.class, sellRequestId);
		return sellRequest2;
	}

	public List<Land> readAllLands(int userId) {
		String jpql4 = "SELECT l FROM Land l INNER JOIN l.user u where u.userId=:user";
		TypedQuery<Land> tquery = entityManager.createQuery(jpql4, Land.class);
		tquery.setParameter("user", userId);
		List<Land> lands = tquery.getResultList();
		if (lands.size() != 0) {
			return lands;
		} else {
			return null;
		}

	}

	public boolean insertInsuranceRequest(AppliedInsurance appliedInsurance) {
		entityManager.merge(appliedInsurance);
		return true;
	}

	public List<AppliedInsurance> readAllAppliedInsuranceDetails(int userId) {
		String jpql4 = "SELECT a FROM AppliedInsurance a INNER JOIN a.user u where u.userId=:user and a.status='NOTCLAIMED'";
		//String jpql4 = "Select a from AppliedInsuarance a where a.user.userId = :user AND a.status='NOTCLAIMED'";
		TypedQuery<AppliedInsurance> tquery = entityManager.createQuery(jpql4, AppliedInsurance.class);
		tquery.setParameter("user", userId);
		List<AppliedInsurance> appliedInsuranceList = tquery.getResultList();
		if (appliedInsuranceList.size() != 0) {
			return appliedInsuranceList;
		} else {
			return null;
		}

	}

	public AppliedInsurance fetchAppliedInsuranceById(int policyNo) {
		AppliedInsurance appliedInsurance =entityManager.find(AppliedInsurance.class, policyNo);
		return appliedInsurance;
	}

	public boolean insertInsuranceClaimRequest(InsuranceForClaim insuranceForClaim) {
		
		entityManager.merge(insuranceForClaim);
		String jpql4 = "UPDATE AppliedInsurance a SET a.status ='CLAIMED' where a.policyNo = :policyNo";
		//System.out.println("Updated");
		Query tquery= entityManager.createQuery(jpql4);
		tquery.setParameter("policyNo",insuranceForClaim.getPolicyNo().getPolicyNo());
		int i = tquery.executeUpdate();
		if(i==1)
			return true;
		else
			return false;
	}

	public List<SellRequest> readAllCurrentBidding() {
		String jpql= "SELECT s FROM SellRequest s where s.status='APPROVED'";
		TypedQuery<SellRequest> tquery = entityManager.createQuery(jpql, SellRequest.class);
		List<SellRequest> bid  = tquery.getResultList();
		if (bid.size() != 0) {
			return bid;
		} else {
			return null;
		}
	}

	public boolean revokeBid(int bidId, int sellRequestId) {
		String jpql = "UPDATE SellRequest s SET s.status ='REMOVED' where s.requestId=:requestId1";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("sellRequestId1", sellRequestId);
		int result = query.executeUpdate();
		if(result==1)
			return true;
		else 
			return false;
	}
	public boolean accceptBid(int bidId, int sellRequestId) {
		String jpql = "UPDATE SellRequest s SET s.status ='ACCEPTED' where s.requestId=:requestId1";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("sellRequestId1", sellRequestId);
		int result = query.executeUpdate();
		if(result==1)
			return true;
		else 
			return false;
	}

	

}
