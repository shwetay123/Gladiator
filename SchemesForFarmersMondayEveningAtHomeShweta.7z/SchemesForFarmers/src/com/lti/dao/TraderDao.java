package com.lti.dao;

import java.util.List;

import com.lti.model.BidRequest;
import com.lti.model.SellRequest;

public interface TraderDao {

	public int addBidRequest(BidRequest bidRequest);

	public List<SellRequest> readSellRequest();
	
	public int updateCurrentBidAmount(int requestId,float bidAmount,int userId);
	
}
