package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Admin;
import com.lti.model.InsuranceForClaim;
import com.lti.model.SellRequest;
import com.lti.model.User;

@Repository
public class AdminDaoImpl implements AdminDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private User user;

	public List<User> findRegistrationPendingRequest() {
		String jpql = "Select u from User u where u.status ='PENDING' ";
		TypedQuery<User> tquery = entityManager.createQuery(jpql, User.class);
		List<User> list = tquery.getResultList();
		if (list.size() != 0) {
			return list;
		} else {
			return null;
		}
	}

	public int rejectUser(int userId) {
		/*
		 * String jpql ="delete u from User u where u.userId=:userId"; Query
		 * query= entityManager.createQuery(jpql); query.setParameter("userId",
		 * userId); int result = query.executeUpdate();
		 */
		// String jpql = "delete l from Land l where l.userId"
		/*
		 * User user = entityManager.find(User.class, userId);
		 * entityManager.remove(user); return 1;
		 */
		String jpql = "UPDATE User u SET u.status = 'REJECTED' where u.userId=:userId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("userId", userId);
		int result = query.executeUpdate();
		return result;
	}

	public int updateLoginStatus(int userId) {
		String jpql = "UPDATE User u SET u.status = 'APPROVED' where u.userId=:userId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("userId", userId);
		int result = query.executeUpdate();
		return result;
	}

	public Admin readAdminLogin(String username, String password) {
		String jpql = "Select a from Admin a where a.username=:uname and a.password=:pass";
		TypedQuery<Admin> tquery = entityManager.createQuery(jpql, Admin.class);
		tquery.setParameter("uname", username);
		tquery.setParameter("pass", password);
		Admin admin = tquery.getSingleResult();
		return admin;

	}

	public User readUserDetails(int userId) {
		User user = entityManager.find(User.class, userId);
		if (user != null)
			return user;
		else
			return null;
	}

	public List<SellRequest> findPendingSellRequest() {
		String jpql = "Select s from SellRequest s where s.status ='PENDING' ";
		TypedQuery<SellRequest> tquery = entityManager.createQuery(jpql, SellRequest.class);
		List<SellRequest> list = tquery.getResultList();
		System.out.println(list);
		if (list.size() != 0) {
			return list;
		} else {
			return null;
		}
	}

	public int updateSellRequestStatus(int requestId) {
		String jpql = "UPDATE SellRequest s SET s.status = 'APPROVED' where s.requestId=:requestId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("requestId", requestId);
		int result = query.executeUpdate();
		return result;
	}

	public int rejectSellRequest(int requestId) {
		String jpql = "UPDATE SellRequest s SET s.status = 'REJECTED' where s.requestId=:requestId";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("requestId", requestId);
		int result = query.executeUpdate();
		return result;
	}

	public List<InsuranceForClaim> readAllClaimedinsurance() {
		String jpql = "Select c from InsuranceForClaim c where c.status ='NOTAPPROVED'";
		TypedQuery<InsuranceForClaim> tquery = entityManager.createQuery(jpql, InsuranceForClaim.class);
		List<InsuranceForClaim> list = tquery.getResultList();
		System.out.println(list);
		if (list.size() != 0) {
			return list;
		} else {
			return null;
		}

	}

	public boolean approveClaimedInsurance(int policyNo) {
		String jpql = "UPDATE InsuranceForClaim c SET c.status = 'APPROVED' where c.policyNo.policyNo=:policyNo1";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("policyNo1", policyNo);
		int result = query.executeUpdate();
		if(result==1)
			return true;
		else 
			return false;
	}
	
	public boolean cropSold(int bidId, int sellRequestId) {
		String jpql = "UPDATE SellRequest s SET s.status ='SOLD' where s.requestId=:requestId1";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("sellRequestId1", sellRequestId);
		int result = query.executeUpdate();
		if(result==1)
			return true;
		else 
			return false;
	}


}
