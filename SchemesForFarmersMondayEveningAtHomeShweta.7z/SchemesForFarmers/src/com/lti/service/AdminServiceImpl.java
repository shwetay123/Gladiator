package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.AdminDao;
import com.lti.model.Admin;
import com.lti.model.InsuranceForClaim;
import com.lti.model.SellRequest;
import com.lti.model.User;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao dao;

	@Transactional
	public List<User> readRegistrationPendingRequest() {
		List<User> list = dao.findRegistrationPendingRequest();
		return list;
	}

	@Transactional
	public boolean rejectRegistration(int userId) {
		int result = dao.rejectUser(userId);
		if (result == 1)
			return true;
		else
			return false;
	}

	@Transactional
	public boolean approveRegistration(int userId) {
		int result = dao.updateLoginStatus(userId);
		if (result == 1)
			return true;
		else
			return false;
	}

	@Transactional
	public Admin adminCheckLogin(String username, String password) {
		Admin admin = dao.readAdminLogin(username, password);
		if (admin != null)
			return admin;
		else
			return null;
	}

	@Transactional
	public User getUserDetails(int userId) {
		User user = dao.readUserDetails(userId);
		return user;
	}

	@Transactional
	public List<SellRequest> readPendingSellRequest() {
		List<SellRequest> list = dao.findPendingSellRequest();
		return list;

	}

	@Transactional
	public boolean approveSellRequest(int requestId) {
		int result = dao.updateSellRequestStatus(requestId);
		if (result == 1)
			return true;
		else
			return false;
	}

	@Transactional
	public boolean rejectSellRequest(int requestId) {
		int result = dao.rejectSellRequest(requestId);
		if (result == 1)
			return true;
		else
			return false;
	}

	public List<InsuranceForClaim> fetchAllClaimedinsurance() {
		List<InsuranceForClaim> list = dao.readAllClaimedinsurance();
		if (list != null)
			return list;
		else
			return null;
	}

	public int approveClaimedInsurance(int policyNo) {
		boolean result = dao.approveClaimedInsurance(policyNo);
		if (result)
			return 1;
		else
			return 0;

	}

	public int cropSold(int bidId, int sellRequestId) {
		boolean  result  = dao.cropSold( bidId,  sellRequestId);
		if (result)
			return 1;
		else
			return 0;

	}

	public List<SellRequest> fetchAllCurrentBiddingForAdmin() {
		List<SellRequest>  list = dao.fetchAllCurrentBiddingForAdmin();
		if(list !=null)
			return list;
		else
			return null;
	}

}
