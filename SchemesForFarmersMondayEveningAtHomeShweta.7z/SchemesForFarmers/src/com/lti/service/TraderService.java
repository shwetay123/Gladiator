package com.lti.service;

import java.util.List;

import com.lti.model.BidRequest;
import com.lti.model.SellRequest;

public interface TraderService {
	 
	public boolean insertBidRequest(BidRequest bidRequest);

	public List<SellRequest> getSellRequest();

	public boolean changeCurrentBidAmount(int requestId,float bidAmount,int userId);
	
}
