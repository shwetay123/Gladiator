package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.FarmerDao;
import com.lti.model.AppliedInsurance;
import com.lti.model.BidRequest;
import com.lti.model.Crop;
import com.lti.model.InsuranceForClaim;
import com.lti.model.Land;
import com.lti.model.SellRequest;
import com.lti.model.User;

@Service
public class FarmerServiceImpl implements FarmerService {

	@Autowired
	private FarmerDao dao;
	
	

	@Transactional
	public List<Crop> fetchCropDetails() {
		List<Crop> list = dao.readAllCrops();
		return list;
	}

	@Transactional
	public Crop getCropById(int cropId) {
		Crop crop = dao.readCropById(cropId);
		return crop;
	}

	@Transactional
	public boolean addSellRequest(SellRequest sellRequest) {
		System.out.println(sellRequest);
		int result = dao.insertSellRequest(sellRequest);
		System.out.println(result);
		if (result == 1) {
			return true;
		} else {
			return false;
		}

	}

	public User getUserById(int userId) {
		User user = dao.readUserById(userId);
		return user;
	}

	@Transactional
	public boolean addLandDetails(Land land) {
		int result = dao.insertLandDetails(land);
		System.out.println(result);
		if (result == 1) {
			return true;
		} else {
			return false;
		}
	}

	/*
	 * public List<Land> fetchAllLands() { List<Land> list = dao.readAllLands();
	 * return list; }
	 */

	public SellRequest getSellRequestDetails(int sellRequestId) {
		SellRequest sellRequest = dao.readSellRequestById(sellRequestId);
		return sellRequest;
	}

	public List<Land> fetchAllLands(int userId) {
		List<Land> list = dao.readAllLands(userId);
		return list;

	}

	@Transactional
	public int addInsuranceRequest(AppliedInsurance appliedInsurance) {
		boolean result = dao.insertInsuranceRequest(appliedInsurance);
		if (result)
			return 1;
		else
			return 0;

	}

	
	public List<AppliedInsurance> fetchAllAplliedInsurance(int userId) {
		List<AppliedInsurance> appliedInsuranceList = dao.readAllAppliedInsuranceDetails(userId);
		if (appliedInsuranceList != null)
			return appliedInsuranceList;
		else
			return null;

	}

	public AppliedInsurance getAppliedInsuranceById(int policyNo) {
		AppliedInsurance appliedInsurance= dao.fetchAppliedInsuranceById(policyNo);
		if(appliedInsurance != null)
			return appliedInsurance;
		else
			return null;
			
		
	}

	@Transactional
	public int addInsuranceClaimRequest(InsuranceForClaim insuranceForClaim) {
		boolean result = dao.insertInsuranceClaimRequest(insuranceForClaim);
		if(result)
			return 1;
		else
			return 0;
	}

	public List<SellRequest> fetchAllCurrentBidding() {
		List<SellRequest> list = dao.readAllCurrentBidding();
		if(list != null )
			return list;
		else
			return null;
		
	}

	public int revokeBid(int bidId, int sellRequestId) {
		boolean result = dao.revokeBid(bidId,sellRequestId);
		if(result)
			return 1;
		else 
			return 0;
	}

	
	public int acceptBid(int bidId, int sellRequestId) {
		boolean result = dao.revokeBid(bidId,sellRequestId);
		if(result)
			return 1;
		else 
			return 0;
	}

}
