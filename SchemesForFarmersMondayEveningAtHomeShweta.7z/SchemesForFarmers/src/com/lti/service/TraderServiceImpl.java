package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.TraderDao;
import com.lti.model.BidRequest;
import com.lti.model.SellRequest;

@Service
public class TraderServiceImpl implements TraderService {
	
	@Autowired
	private TraderDao dao;

	@Transactional
	public boolean insertBidRequest(BidRequest bidRequest) {
		int result = dao.addBidRequest(bidRequest);
		if(result == 1)
			return true;
		else
			return false;
		
	}
	
	@Transactional
	public List<SellRequest> getSellRequest() {
		List<SellRequest> sellRequestlist = dao.readSellRequest();
		return sellRequestlist;
	}
	
	@Transactional
	public boolean changeCurrentBidAmount(int requestId, float bidAmount, int userId) {
		int result = dao.updateCurrentBidAmount(requestId, bidAmount,userId);
		if(result==1)
			return true;
		else
			return false;
	}

}
