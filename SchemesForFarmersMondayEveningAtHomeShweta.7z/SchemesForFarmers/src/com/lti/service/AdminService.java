package com.lti.service;

import java.util.List;

import com.lti.model.Admin;
import com.lti.model.InsuranceForClaim;
import com.lti.model.SellRequest;
import com.lti.model.User;

public interface AdminService {
	
	public List<User> readRegistrationPendingRequest();
	public boolean rejectRegistration(int userId) ;
	public boolean approveRegistration(int userId);
	public Admin adminCheckLogin(String username,String password);
	public User getUserDetails(int userId);
	public List<SellRequest> readPendingSellRequest();
	public boolean approveSellRequest(int requestId);
	public boolean rejectSellRequest(int requestId);
	public List<InsuranceForClaim> fetchAllClaimedinsurance();
	public int approveClaimedInsurance(int policyNo);
	public int cropSold(int bidId, int sellRequestId);
	public List<SellRequest> fetchAllCurrentBiddingForAdmin();

}
