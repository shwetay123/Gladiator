package com.lti.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.lti.model.AppliedInsurance;
import com.lti.model.BidRequest;
import com.lti.model.Crop;
import com.lti.model.InsuranceForClaim;
import com.lti.model.Land;
import com.lti.model.SellRequest;
import com.lti.model.User;
import com.lti.service.FarmerService;

@Controller
public class FarmerController {

	LocalDate localDate = LocalDate.now();

	private static final DateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

	@Autowired
	private Land land;

	@Autowired
	private SellRequest sellRequest;

	@Autowired
	private FarmerService service;

	@Autowired
	private AppliedInsurance appliedInsurance;
	@Autowired
	private InsuranceForClaim insuranceForClaim;

	@RequestMapping(path = "welcomeFarmerPage", method = RequestMethod.GET)
	public String viewAdminWelcome() {
		return "welcomeFarmer";
	}

	@RequestMapping(path = "sellRequestPage", method = RequestMethod.GET)
	public String sellRequestPage() {

		return "placeSellRequestPage";

	}

	public Crop getCropById(@RequestParam("cropId") int cropId) {
		Crop crop = service.getCropById(cropId);
		return crop;

	}

	public User getUserById(@RequestParam("userId") int userId) {
		User user = service.getUserById(userId);
		return user;

	}

	@RequestMapping(path = "sellRequestPage.do", method = RequestMethod.POST)
	public String placeSellRequest(@RequestParam("fertilizerType") String fertilizerType,
			@RequestParam("quantity") int quantity, @RequestParam("soilphcertificate") String phCertificate,
			@RequestParam("basePrice") float basePrice, @RequestParam("status") String status,
			@RequestParam("userId") int userId, @RequestParam("cropName") int cropId) {

		sellRequest.setfertilizerType(fertilizerType);
		sellRequest.setQuantity(quantity);
		sellRequest.setphCertificate(phCertificate);
		sellRequest.setbasePrice(basePrice);
		sellRequest.setcurrentBid(basePrice);

		// System.out.println(DateTimeFormatter.ofPattern("yyyy-MM-dd").format(localDate));
		sellRequest.setrequestDate("01-01-17"/*
												 * DateTimeFormatter.ofPattern( "yyyy-MM-dd").format(localDate)
												 */);
		sellRequest.setStatus(status);

		Crop crop = getCropById(cropId);
		sellRequest.setCrop(crop);

		User user = getUserById(userId);
		sellRequest.setUser(user);
		boolean result = service.addSellRequest(sellRequest);
		if (result)
			return "sellRequestSuccess";
		else
			return "sellRequestError";

	}

	@RequestMapping(path = "addLandPage")
	public String addLand() {
		return "addLand";
	}

	@RequestMapping(path = "addLandDetail.do", method = RequestMethod.POST)
	public String addLand(Model model, @RequestParam("area") float area, @RequestParam("address") String address,
			@RequestParam("pincode") long pincode, @RequestParam("userId") int userId) {
		land.setLandAddress(address);
		land.setLandArea(area);
		land.setLandPincode(pincode);

		User user = getUserById(userId);
		land.setUser(user);
		model.addAttribute("userId", user);
		boolean result = service.addLandDetails(land);

		if (result)
			return "landAddedSuccess";
		else
			return "errorPage";

	}

	@RequestMapping(path = "viewLandDetails", method = RequestMethod.GET)
	public String viewLandDetails(Model model, @SessionAttribute("userId") int userId) {

		List<Land> lands = service.fetchAllLands(userId);
		if (lands.size() != 0) {
			model.addAttribute("ListOfLand", lands);
			return "viewLands";
		} else {
			return "errorPage";
		}

	}

	@RequestMapping(path = "applyInsurancePage", method = RequestMethod.GET)
	public String applyInsurance() {
		return "applyInsurance";
	}

	@RequestMapping(path = "claimInsurancePage", method = RequestMethod.GET)
	public String claimInsurance(Model model, @SessionAttribute("userId") int userId) {
		List<AppliedInsurance> appliedInsuranceList = service.fetchAllAplliedInsurance(userId);
		if (appliedInsuranceList != null) {
			model.addAttribute("appliedInsuranceList", appliedInsuranceList);
			return "claimInsurance";
		} else
			return "noInsuranceToClaim";

	}

	@RequestMapping(path = "insurancePage")
	public String insurance() {
		return "insurance";
	}

	@RequestMapping(path = "applyInsurance.do", method = RequestMethod.POST)
	public String applyInsurance(@RequestParam("userId") String userId, @RequestParam("cropName") String cropName,
			@RequestParam("companyName") String companyName, @RequestParam("year") String year,
			@RequestParam("status") String status, @RequestParam("totalSumInsured") String totalSumInsured) {

		appliedInsurance.setCompanyName(companyName);
		appliedInsurance.setStatus(status);
		appliedInsurance.setTotalSumInsured(Long.parseLong(totalSumInsured));
		appliedInsurance.setYear(Integer.parseInt(year));
		appliedInsurance.setCropName(cropName);
		appliedInsurance.setUser(service.getUserById(Integer.parseInt(userId)));
		String appliedDate = DateTimeFormatter.ofPattern("yyyy-MM-dd").format(localDate);
		appliedInsurance.setAppliedDate(appliedDate);

		int result = service.addInsuranceRequest(appliedInsurance);
		if (result == 1) {
			return "insuranceAppliedSuccess";
		} else {
			return "insuranceAppliedError";
		}

	}

	@RequestMapping(path = "claimInsurance.do", method = RequestMethod.POST)
	public String claimInsurance(@RequestParam("insuarance") int policyNo,
			@RequestParam("dateOfLoss") String dateOfLoss, @RequestParam("causeOfLoss") String causeOfLoss,
			@RequestParam("status") String claimStatus) {
		insuranceForClaim.setCauseOfLoss(causeOfLoss);
		insuranceForClaim.setClaimStatus(claimStatus);
		insuranceForClaim.setDateOfLoss(dateOfLoss);
		appliedInsurance = service.getAppliedInsuranceById(policyNo);
		insuranceForClaim.setPolicyNo(appliedInsurance);

		int result = service.addInsuranceClaimRequest(insuranceForClaim);
		if (result == 1)
			return "claimInsurancePage";
		else
			return "claimInsuranceUnsuccessfull";
	}

	@RequestMapping(path="viewCurrentBiddingPage")
	public String viewCurrentBidding(Model model){
		List<SellRequest> list=service.fetchAllCurrentBidding();
		if(list !=null){
			model.addAttribute("BiddingRequestList", list);
			return "viewCurrentBidding";
		}else
			return "noCurrentBidding";
		
	}

	@RequestMapping(path="revokeBid.do")
	public String revokeBid(@RequestParam("bidId") int bidId, @RequestParam("sellRequestId") int sellRequestId ) {
		int result = service.revokeBid(bidId,sellRequestId);
		if(result==1)
			return "viewCurrentBiddingPage";
		else 
			return "revokeUnsuccess";
	}
	
	@RequestMapping(path="acceptBid.do")
	public String acceptBid(@RequestParam("bidId") int bidId, @RequestParam("sellRequestId") int sellRequestId ) {
		int result = service.acceptBid(bidId,sellRequestId);
		if(result==1)
			return "viewCurrentBiddingPage";
		else 
			return "acceptUnsuccess";
		
	}
	

}
