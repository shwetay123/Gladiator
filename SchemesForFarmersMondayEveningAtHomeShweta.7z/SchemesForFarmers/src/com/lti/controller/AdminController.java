package com.lti.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.Admin;
import com.lti.model.InsuranceForClaim;
import com.lti.model.SellRequest;
import com.lti.model.User;
import com.lti.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	private AdminService service;

	@Autowired
	private User user;

	HttpSession session;

	@RequestMapping(path = "welcomeAdminPage", method = RequestMethod.GET)
	public String viewAdminWelcome() {
		return "welcomeAdmin";
	}

	@RequestMapping(path = "viewRegistrationPendingRequest", method = RequestMethod.GET)
	public String viewRegistrationPendingRequest(Model model) {
		List<User> user = service.readRegistrationPendingRequest();
		model.addAttribute("UserList", user);
		return "AdminApprovalForRegistration";
	}

	@RequestMapping(path = "approveUser.do", method = RequestMethod.GET)
	public String approveUser(@RequestParam("userId") int userId) {
		boolean result = service.approveRegistration(userId);
		if (result)
			return "redirect:viewRegistrationPendingRequest";
		else
			return "";

	}

	@RequestMapping(path = "deleteUser.do", method = RequestMethod.GET)
	public String rejectUser(@RequestParam("userId") int userid) {
		boolean result = service.rejectRegistration(userid);
		if (result)
			return "redirect:viewRegistrationPendingRequest";
		else
			return "";

	}

	@RequestMapping(path = "adminLogin.do", method = RequestMethod.POST)
	public String adminLogin(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("username") String username, @RequestParam("password") String password) {
		Admin admin = service.adminCheckLogin(username, password);
		String userName = admin.getUsername();

		if (admin != null) {
			session = request.getSession(true);
			session.setAttribute("userName", userName);
			return "welcomeAdmin";
		} else
			return "adminLogin";

	}
	@RequestMapping(path="adminLogout.do" , method= RequestMethod.GET)
	public String userLogout(HttpServletResponse response, HttpServletRequest request){
	  session = request.getSession(false);
		if(session != null)
		{
			session.invalidate();
		}
		return "adminLogin";
	}

	@RequestMapping(path = "userDetails.view", method = RequestMethod.GET)
	public String getUserDetails(@RequestParam("userId") int userId, Model model) {
		User user = service.getUserDetails(userId);
		model.addAttribute("user", user);
		return "userDetails";
	}

	@RequestMapping(path = "viewPendingSellRequest", method = RequestMethod.GET)
	public String viewPendingSellRequest(Model model) {
		List<SellRequest> sellRequest = service.readPendingSellRequest();
		model.addAttribute("SellRequestList", sellRequest);
		return "adminApprovalForSellRequest";
	}

	@RequestMapping(path = "approveSellRequest.do", method = RequestMethod.GET)
	public String approveSellRequest(@RequestParam("requestId") int requestId) {
		boolean result = service.approveSellRequest(requestId);
		if (result)
			return "redirect:viewPendingSellRequest";
		else
			return "";

	}

	@RequestMapping(path = "deleteSellRequest.do", method = RequestMethod.GET)
	public String rejectSellRequest(@RequestParam("requestId") int requestId) {
		boolean result = service.rejectSellRequest(requestId);
		if (result)
			return "rejectionRemarkPage";
		else
			return "";
	}
	
	
	@RequestMapping(path="viewClaimedInsurancePage")
	public String viewClaimedInsurance(Model model){
		List<InsuranceForClaim> claimedInsuranceList= service.fetchAllClaimedinsurance();
		if (claimedInsuranceList != null) {
			model.addAttribute("claimedInsuranceList", claimedInsuranceList);
			return "viewClaimedInsurance";
		} else
			return "noClaimedInsurance";
	}
	
	@RequestMapping(path="approveClaimedInsurance.do")
	public String approveClaimedInsurance(@RequestParam("policyNo") int policyNo){
		int result = service .approveClaimedInsurance(policyNo);
		if(result ==1)
			return "viewClaimedInsurancePage";
		else
			return "deletionError";
		
	}
	
	@RequestMapping(path="approveFinalBidRequest.do")
	public String approveFinalBid(Model model) {
		List<SellRequest> list=service.fetchAllCurrentBiddingForAdmin();
		if(list !=null) {
			model.addAttribute("ListOfBids", list)
			return "acceptedBidsByFarmer";
		}
		else
			return "nodataFound";
	}
	
	@RequestMapping(path="approveBid.do")
	public String cropSold(int bidId,int sellRequestId) {
		int result = service.cropSold(bidId, sellRequestId);
		if(result==1)
			return "";
		else
			return "";
	}
}
