package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.SellRequest;
import com.lti.service.TraderService;

@Controller
public class TraderController {

	@Autowired
	private SellRequest sellRequest;

	@Autowired
	private TraderService service;

	@RequestMapping(path = "welcomeTraderPage", method = RequestMethod.GET)
	public String welcomeTrade(Model model) {
		//List<SellRequest> list = service.getSellRequest();
		//model.addAttribute("SellRequestList", list);
		return "welcomeTrader";

	}
	
	@RequestMapping(path = "updateAmount", method = RequestMethod.GET)
	public String changeCurrentBidAmount(@RequestParam(name="requestId") int requestId,@RequestParam(name="changedAmount") long bidAmount,
			@RequestParam(name="userId") int userId ) {
		boolean result = service.changeCurrentBidAmount(requestId, bidAmount, userId);
		if(result)
			return "welcomeTrader";
		else
			return "welcomeTrader";

	}
	
	/*
	 * @RequestMapping(path="addBidRequest.do") public String
	 * addBidRequest(@RequestParam){
	 * 
	 * 
	 * 
	 * boolean result = service.insertBidRequest(bidRequest);
	 * 
	 * return null;
	 * 
	 * }
	 */
}
