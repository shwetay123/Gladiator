package com.lti.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.lti.model.SellRequest;
import com.lti.model.User;
import com.lti.service.TraderService;
import com.lti.service.UserService;

@Controller
public class MainController {

	@Autowired
	private UserService service;

	@Autowired
	private TraderService tservice;

	@Autowired
	private User user;
	
	HttpSession session;

	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String index() {
		return "index";
	}

	@RequestMapping(path = "register", method = RequestMethod.GET)
	public String register() {
		return "register";
	}

	@RequestMapping(path = "login", method = RequestMethod.GET)
	public String loginPage() {
		return "login";
	}

	@RequestMapping(path = "notApproved", method = RequestMethod.GET)
	public String notApprovedpage() {
		return "notApproved";
	}

	@RequestMapping(path = "invalidUser", method = RequestMethod.GET)
	public String invalidUserpage() {
		return "invalidUser";
	}

	@RequestMapping(path = "adminLogin", method = RequestMethod.GET)
	public String adminLoginPage() {
		return "adminLogin";
	}

	@RequestMapping(path = "registerUser.do", method = RequestMethod.POST)
	public String registerUser(Model model,@RequestParam("firstname") String firstName,
			@RequestParam("middlename") String middleName, @RequestParam("lastname") String lastName,
			@RequestParam("contactnumber") String phoneNumber, @RequestParam("email") String email,
			@RequestParam("landmark") String landmark, @RequestParam("locality") String locality,
			@RequestParam("pincode") long pincode, @RequestParam("district") String district,
			@RequestParam("state") String state, @RequestParam("accountnumber") String accountNumber,
			@RequestParam("ifsccode") String ifscCode, @RequestParam("aadharCard") MultipartFile aadharCard,
			@RequestParam("panCard") MultipartFile panCard,
			@RequestParam("liscenseCertificate") MultipartFile certificate, @RequestParam("password") String password,
			@RequestParam("role") String role, @RequestParam("status") String status) {

		
		String path="D:/upload/def/";
		String aadharFinalPath= path+aadharCard.getOriginalFilename();
		String panFinalPath= path+panCard.getOriginalFilename();
		String liscenseCertificateFinalPath= path+certificate.getOriginalFilename();
		
		try{
			aadharCard.transferTo(new File(aadharFinalPath));
			panCard.transferTo(new File(panFinalPath));
			certificate.transferTo(new File(liscenseCertificateFinalPath));
			
		}catch(IOException e){
			System.out.println("Failed to upload file" +e);
		}
		
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setMiddleName(middleName);
		user.setPhoneNumber(phoneNumber);
		user.setEmail(email);
		user.setLandmark(landmark);
		user.setLocality(locality);
		user.setPincode(pincode);
		user.setDistrict(district);
		user.setState(state);
		user.setAccountNumber(accountNumber);
		user.setIfscCode(ifscCode);
		user.setAadharCard(aadharFinalPath);
		user.setPanCard(panFinalPath);
		user.setCertificate(liscenseCertificateFinalPath);
		user.setPassword(password);
		user.setRole(role);
		user.setStatus(status);

		boolean result = service.registerUser(user);
		if (result)
			return "registrationSuccess";
		else
			return "registrationError";
	}

	@RequestMapping(path = "login.do", method = RequestMethod.POST)
	public String login(HttpServletRequest request, HttpServletResponse response,
			@RequestParam("username") String username, @RequestParam("password") String password, Model model) {

		User user = service.checkLogin(username, password);
		int userId= user.getUserId();
		
		if(user !=null){
			if (user.getStatus().equalsIgnoreCase("APPROVED")) {

				if (user.getRole().equalsIgnoreCase("farmer")) {
					 session = request.getSession(true);
					session.setAttribute("userId", userId);
					return "welcomeFarmer";

				} else {
					session = request.getSession(true);
					session.setAttribute("userId", userId);
					return "redirect:welcomeTraderPage";
				}

			} 
			else{
				return "notApproved";
			} 

		}
		else
		{
			return "invalidUser";
		}

	}
	
	
	@RequestMapping(path="logout.do" , method= RequestMethod.GET)
	public String userLogout(HttpServletResponse response, HttpServletRequest request){
	  session = request.getSession(false);
		if(session != null)
		{
			session.invalidate();
		}
		return "login";
	}

}
