$(document).ready(function() {
	var max_fields      = 10; //maximum input boxes allowed
	var wrapper   		= $(".input_fields_wrap"); //Fields wrapper
	var add_button      = $("#add_field_button"); //Add button ID
	
	var x = 1; //initlal text box count
	$(add_button).click(function(e){ //on add input button click
		e.preventDefault();
		if(x < max_fields){ //max input box allowed
			x++; //text box increment
			$(wrapper).append('<div align="center"><table align="center" colspacing="15px" cellspacing="15px">'+
			'<tr><td>Area</td><td><input type="number" name="area'+x+'" placeholder="Enter Area in hector" class="" length="5" required/></td></tr>'+
			'<tr><td>Address</td><td><input type="text" name="address'+x+'" placeholder="Locality/ Street" length="40" class="" required/></td></tr>'+
			'<tr><td>Pincode</td><td><input type="number" name="pincode'+x+'" placeholder="Enter Pincode" length="6" class="" required/></td></tr></table>'+
			'<input align="center" type="button" class="remove_field" value="Remove">'+
			'</div>'); 
		}
	});
	
	$(wrapper).on("click",".remove_field", function(e){ //user click on remove text
		e.preventDefault(); $(this).parent('div').remove(); x--;
	})
});

$(document).ready(function() {
    $('input[type=radio][name=role]').change(function() {
    if (this.value == 'farmer') {
        $("#land").css("display", "block");
    }
    else if (this.value == 'trader') {
        $("#land").css("display", "none");

    }
});
});

